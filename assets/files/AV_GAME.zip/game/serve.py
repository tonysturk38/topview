from http.server import SimpleHTTPRequestHandler
from socketserver import TCPServer

class CORSEnabledRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', 'https://retail.playmanbet.com')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200, "ok")
        self.send_header('Access-Control-Allow-Origin', 'https://retail.playmanbet.com')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

if __name__ == '__main__':
    with TCPServer(('127.0.0.1', 3000), CORSEnabledRequestHandler) as httpd:
        print("Server started at http://127.0.0.1:3000")
        httpd.serve_forever()
